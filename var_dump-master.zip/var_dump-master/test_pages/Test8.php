<?php
$test5 = [
    'Ford' => 'Fiesta',
    'Toyota' => 'Starlet',
    'Fiat' => 'Uno'
];?>
<p>
<?php var_dump($test5); ?>
</p>
