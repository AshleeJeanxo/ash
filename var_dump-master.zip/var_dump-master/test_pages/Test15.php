<?php

$test15 = [curl_init()];

var_dump($test15);
