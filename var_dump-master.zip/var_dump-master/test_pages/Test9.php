<?php
$test9 = [
    'regular float' => 10.01,
    'another regular float' => 10.0,
    'really large float' => 1000000000000000000.0,
    'really small float' => 0.0000000000000000001
];

var_dump($test9);
?>
