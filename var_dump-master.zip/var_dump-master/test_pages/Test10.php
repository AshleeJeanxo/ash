<?php
$test10 = [
    'array-key-has-dashe\'s' => "<--- I sure hope you see dashses over there",
];

var_dump($test10);
?>
