<?php
$test13 = [
    'array key has at sign: @' => "<--- I sure hope you see an at sign (@) over there",
];

var_dump($test13);
?>
