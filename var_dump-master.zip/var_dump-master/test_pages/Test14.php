<?php

$test14 = [ "@a"=> "a"];
$test14 = (object)$test14;

var_dump($test14);
