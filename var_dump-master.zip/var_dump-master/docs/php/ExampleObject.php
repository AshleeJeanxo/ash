<?php
class ExampleObject {
	public $ExtensionName = "Var_Masterpiece";
    public $AuthorName = "Philip Reasa";
    public $ExtensionAbilities = array(
    	"Tree Nesting Structure" => array(
    		"Arbitrary Debpth?" => "Yup!",
    		"Expanding and Collapsing?" => "You bet",
    		"Associative Arrays?" => "Apperantly :P"
    	),
    	"Custimizable Data Type Coloring",
        "Automatically Runs", 
        "Selectivly Run Within A Page"
    );
    public $GitHub = "Contribute here: https://github.com/Rece/var_dump";
    public $TestBooleans = true;
    public $TestInts = 1;
    public $TestFloats = 3.14;
    public $TestNulls = NULL;
}